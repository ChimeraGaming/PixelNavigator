Final Fantasy III

Native NES map data for the RetroAchievements-supported Chaos Rush 1.3 English translation.

Contains original cartridge layouts, background tiles, palettes, chest positions, and sprite data.
The app reads live CPU RAM without changing game memory or save files.
512 native local-map records and 256 world-one combinations are preserved, including unused or duplicate native records.
Worlds render only the visible tiles rather than allocating a full 4096 by 4096 bitmap.
Background water uses its original cartridge frame.

Game: Square. Translation: Chaos Rush. Map format reference: everything8215.
https://github.com/everything8215/ff3
https://retroachievements.org/game/5553/hashes
